檔案說明
test.csv 測試資料集
train.csv 訓練資料集
Wine.csv 原始資料
requirement.txt 依賴套件
main.py 主程式
main.ipynd 適用於jupyter版本
執行程式指令
1.	pip install requirement.txt
2.	python main.py
