report.pdf為報告
main.py為程式碼檔案
Data為存放測試和訓練資料的資料夾

先備安裝檔案
pip install Pillow
pip install sklearn
pip install numpy
直接執行main.py即可看到訓練結果
python main.py